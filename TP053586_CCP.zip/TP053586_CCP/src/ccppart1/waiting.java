package ccppart1;

public class waiting {

	String waname;
	
	 public waiting(String waname)
	    {
	        this.waname=waname;
	    }
}
